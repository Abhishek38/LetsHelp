# LetsHelp
An Android-app to help out the people by donating money, clothes and blood at nearby places
