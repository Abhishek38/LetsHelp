package ashu.help.letshelp.com.letshelp.Adapters.Adapter.ClothesAdapter;


class ClothesUtil {

    public String name_of_skill;
    public int image_of_skill;

    public ClothesUtil(String name_of_skill, int image_of_skill) {
        this.name_of_skill = name_of_skill;
        this.image_of_skill = image_of_skill;
    }



}
