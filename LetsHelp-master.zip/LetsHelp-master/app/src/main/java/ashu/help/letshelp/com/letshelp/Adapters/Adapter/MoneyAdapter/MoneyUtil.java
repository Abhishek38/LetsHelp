package ashu.help.letshelp.com.letshelp.Adapters.Adapter.MoneyAdapter;


class MoneyUtil {

    public String name_of_skill;
    public int image_of_skill;

    public MoneyUtil(String name_of_skill, int image_of_skill) {
        this.name_of_skill = name_of_skill;
        this.image_of_skill = image_of_skill;
    }



}
