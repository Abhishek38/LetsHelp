package ashu.help.letshelp.com.letshelp.Adapters.Adapter.Event;


class EventHolder {

    public String name_of_skill;
    public int image_of_skill;

    public EventHolder(String name_of_skill, int image_of_skill) {
        this.name_of_skill = name_of_skill;
        this.image_of_skill = image_of_skill;
    }



}
