package ashu.help.letshelp.com.letshelp.Adapters.Adapter.RequestBloodAdapter;


class RequestHolder {

    public String holdername,holderbloodgrp,holderbloodunits;

    public RequestHolder(String holdername, String holderbloodgrp, String holderbloodunits) {
        this.holdername = holdername;
        this.holderbloodgrp = holderbloodgrp;
        this.holderbloodunits = holderbloodunits;
    }





}
