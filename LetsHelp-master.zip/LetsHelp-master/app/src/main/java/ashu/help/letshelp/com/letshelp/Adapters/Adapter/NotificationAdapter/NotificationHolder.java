package ashu.help.letshelp.com.letshelp.Adapters.Adapter.NotificationAdapter;


class NotificationHolder {

    public String name_of_skill;

    public NotificationHolder(String name_of_skill) {
        this.name_of_skill = name_of_skill;

    }



}
